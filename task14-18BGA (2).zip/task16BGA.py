# todo: База данных пользователя.
# Задан массив объектов пользователя

users = [{'login': 'Piter', 'age': 23, 'group': "admin"},
         {'login': 'Ivan',  'age': 10, 'group': "guest"},
         {'login': 'Dasha', 'age': 30, 'group': "master"},
         {'login': 'Fedor', 'age': 13, 'group': "guest"}]

Написать фильтр который будет выводить отсортированные объекты по возрасту(больше введеного)
,первой букве логина, и заданной группе.




users = [
    {'login': 'Piter', 'age': 23, 'group': "admin"},
    {'login': 'Ivan',  'age': 10, 'group': "guest"},
    {'login': 'Dasha', 'age': 30, 'group': "master"},
    {'login': 'Fedor', 'age': 13, 'group': "guest"}
]

print("1. По возрасту\n2. По первой букве\n3. По группе")
sort_type = input("Тип сортировки: ")
criterion = input("Введите критерии поиска: ")

# Словарь условий фильтрации
filters = {
    "1": lambda u: u['age'] > int(criterion),
    "2": lambda u: u['login'].lower().startswith(criterion.lower()),
    "3": lambda u: u['group'] == criterion
}

print("\nРезультат:")
for u in filter(filters[sort_type], users):
    print(f"Пользователь: '{u['login']}' возраст {u['age']} лет, группа \"{u['group']}\"")






