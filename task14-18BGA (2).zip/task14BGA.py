#todo: Дан массив размера N. Найти минимальное растояние между одинаковыми значениями в массиве и вывести их индексы.
# Одинаковых значение может быть два и более !
Пример:
mass = [1,2,17,54,30,89,2,1,6,2]


Для числа 1 минимальное растояние в массиве по индексам: 0 и 7
Для числа 2 минимальное растояние в массиве по индексам: 6 и 9
Для числа 17 нет минимального растояния т.к элемент в массиве один.


mass = [1, 2, 17, 54, 30, 89, 2, 1, 6, 2]

min_distance = float('inf')
indices_pair = None
target_value = None

# Словарь для хранения последнего увиденного индекса каждого числа
last_seen = {}

for current_index, value in enumerate(mass):
    if value in last_seen:
        # Считаем расстояние между текущим индексом и предыдущим для этого же числа
        distance = current_index - last_seen[value]
        if distance < min_distance:
            min_distance = distance
            indices_pair = (last_seen[value], current_index)
            target_value = value
    # Обновляем индекс последнего появления числа
    last_seen[value] = current_index

if indices_pair:
    print(f"Минимальное расстояние ({min_distance}) найдено для числа {target_value}.")
    print(f"Индексы в массиве: {indices_pair[0]} и {indices_pair[1]}")
else:
    print("Повторяющихся элементов с минимальным расстоянием не найдено.")

