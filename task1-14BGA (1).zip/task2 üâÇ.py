
# todo: Преобразуйте переменную age и foo в число
# age = "23"
# foo = "23abc"
#
# Преобразуйте переменную age в Boolean
# age = "123abc"
#
# Преобразуйте переменную flag в Boolean
# flag = 1
#
# Преобразуйте значение в Boolean
# str_one = "Privet"
# str_two = ""
#
# Преобразуйте значение 0 и 1 в Boolean
#
# Преобразуйте False в строку


# 1. Преобразуйте переменную age и foo в число
age = "23"
foo = "23abc"

age_num = int(age)  # Успешно преобразуется в 23

# Так как "23abc" напрямую в число перевести нельзя, используем обработку ошибки
try:
    foo_num = int(foo)
except ValueError:
    # Вариант очистки строки: берем только цифры
    foo_num = int("".join(filter(str.isdigit, foo)))  # Результат: 23


# 2. Преобразуйте переменную age в Boolean
age_str = "123abc"
# Любая непустая строка в Python приводится к True
age_bool = bool(age_str)  


# 3. Преобразуйте переменную flag в Boolean
flag = 1
flag_bool = bool(flag)  # Результат: True


# 4. Преобразуйте значение в Boolean
str_one = "Privet"
str_two = ""
bool_one = bool(str_one)  # Непустая строка -> True
bool_two = bool(str_two)  # Пустая строка -> False


# 5. Преобразуйте значение 0 и 1 в Boolean
zero_bool = bool(0)  # Ноль -> False
one_bool = bool(1)   # Единица -> True


# 6. Преобразуйте False в строку
false_str = str(False)  # Результат: "False"


# Проверка результатов
print(f"1. age: {age_num} ({type(age_num)}), foo: {foo_num} ({type(foo_num)})")
print(f"2. age в bool: {age_bool}")
print(f"3. flag в bool: {flag_bool}")
print(f"4. str_one: {bool_one}, str_two: {bool_two}")
print(f"5. 0 в bool: {zero_bool}, 1 в bool: {one_bool}")
print(f"6. False в str: '{false_str}' ({type(false_str)})")
